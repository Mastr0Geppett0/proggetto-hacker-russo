/*
FONTANAROSA_Antonio 3Di
Si richiede di realizzare in C++ un software che stampi a schermo un men� interattivo
attraverso il quale l�utente possa effettuare le seguenti operazioni:
1.Convertire un numero da base 2 a base 10. E viceversa.
2.Convertire un numero da base 8 a base 5.
3.Convertire un numero da base 16 a base 8.
Si tenga presente che inumeri, nelle relative basi di partenza, dovranno essere inseriti in input dall�utente
durante l�esecuzione del programma.
Consegnare su Teams un file compresso, in formato *.zip, cos� nominato COGNOME_Nome.zip.
*/
#include<iostream>
#include<cmath>
using namespace std;

int scelta_conv();
int dec_bin();
int bin_dec();
int oct_qui();
int exa_oct();

int main(){
	int m = scelta_conv();
	switch(m){
		case 1:
			bin_dec(); //conversione binario-decimale
		break;
		case 2:
			dec_bin(); //conversione decimale-binario
		break;
		case 3:
			oct_qui(); //conversione ottale-quinario
		break;
		case 4:
			exa_oct(); //conversione esadecimale-ottale
		break;
		default:
			cout<<"ERROR!!";
		break;
	}
}
int scelta_conv(){
	int m;
	cout<<"Inserisci 1 per convertire un numero da base 2 a base 10\n"
		<<"Inserisci 2 per convertire un numero da base 10 a base 2\n"
		<<"Inserisci 3 per Convertire un numero da base 8 a base 5\n"
		<<"Inserisci 4 convertire un numero da base 16 a base 8\n";
	cin>>m;
	return m;
}
int bin_dec(){
	const int base = 2;
	int n, i, bit, dec=0;
	cout<<"Inserisci il numero dei bit:\t";
	cin>>bit;
	for(i=0;i<bit;i++){
		do{
			cout<<"Inserisci il bit alla posizione n."<<i<<":\t";
			cin>>n;
		}while(n<0||n>1); //verifica valori
		dec+=n*pow(base,i);
	}
	cout<<"Il numero converito in decimale e':\t"<<dec; //stampa valori
}
int dec_bin(){
	const int base = 2;
	int n, i;
	int bin[i];
	do{
		cout<<"Inserisci un numero decimale positivo:\t";
		cin>>n;
	}while(n<0); //verifica valori
	for(i=0;n>0;i++){
		bin[i]=n%base;
		n=n/base;
	}
	//stampa valori
	for(i--;i>=0;i--){
		cout<<bin[i];
	}
}
int oct_qui(){
	const int base = 8;
	int n, i, cifre, dec=0;
	int qui[i];
	cout<<"Inserisci il numero delle cifre del numero ottale:\t";
	cin>>cifre;
	//conversione ottale-decimale
	for(i=0;i<cifre;i++){
		do{
			cout<<"Inserisci la cifra alla posizione n."<<i<<":\t";
			cin>>n;
		}while(n<0||n>7); //verifica valori
		dec+=n*pow(base,i);
	}
	//conversione decimale-quinario
	for(i=0;n>0;i++){
		qui[i]=n%base;
		n=n/base;
	}
	//stampa valori
	for(i--;i>=0;i--){
		cout<<qui[i];
	}
}
int exa_oct(){
	const int base = 16;
	int n, i, cifre, dec=0;
	int oct[i];
	cout<<"Inserisci il numero delle cifre del numero esadeciale:\t";
	cin>>cifre;
	//conversione esadecimale-decimale
	for(i=0;i<cifre;i++){
		do{
			cout<<"Inserisci la cifra alla posizione n."<<i<<":\t";
			cin>>n;
		}while(n<0||n>15); //verifica valori
		dec+=n*pow(base,i);
	}
	//conversione decimale-ottale
	for(i=0;n>0;i++){
		oct[i]=n%base;
		n=n/base;
	}
	//stampa valori
	for(i--;i>=0;i--){
		cout<<oct[i];
	}
}
