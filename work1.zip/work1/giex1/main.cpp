
#include "prototipo.hpp"

int main(int argc, const char** argv) {
    int n;
    leggi_dim(n);
    int array[n];
    leggi_vet(array,n);
    stampa_vet(array,n);
    return 0;
}
