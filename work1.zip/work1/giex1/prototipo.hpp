#include <iostream>
#include <cmath>
using namespace std;
void leggi_dim(int &);
void leggi_vet(int [],int &);
void stampa_vet(int [],int &);
