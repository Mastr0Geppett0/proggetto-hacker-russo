#include "prototipo.hpp"

void leggi_dim(int &dim){
do
    {
        cout<<"inserisci dimensione array:";
        cin>>dim;
        cout<<endl;
    } while (dim<1);
    return;
}
void leggi_vet(int a[], int &dim){
for (int i = 0; i < dim; i++)
{
    cout<<"\ninserisci elemento:"<<endl;
    cin>>a[i];
}
}
void stampa_vet(int a[], int &dim){
    int x;
    cout<<"\ninserisci un valore X:";
    cin>>x;
    cout<<endl;
        for (int i = 0; i<dim; i++)
        {
            if (a[i]==x)
            {
                cout<<"\n1";
            }
            else
            {
                cout<<"\n0";
            }
        }
    return;
}
